$.emojiarea.path = 'js/packs/basic';
$.emojiarea.icons = { // add icon here
    ':believe:'   : 'believe.jpg',
	':better:'    : 'better.jpg',
	':bless:'     : 'bless.jpg',
	':care:'      : 'care.jpg',
	':cheer:'     : 'cheer.jpg',
	':courage:'   : 'courage.jpg',
	':hug:'       : 'hug.jpg',
	':kiss:'      : 'kiss.jpg',
	':luck:'      : 'luck.jpg',
	':model:'     : 'model.jpg',
	':partner:'   : 'partner.jpg',
	':power:'     : 'power.jpg',
	':sad:'       : 'sad.jpg',
	':support:'   : 'support.jpg',
	':takecare:'  : 'takecare.jpg',
	':thank:'     : 'thank.jpg',
    ':together:'  : 'together.jpg',
    ':touch:'     : 'touch.jpg',
    ':victory:'   : 'victory.jpg',
    ':workhard:'  : 'workhard.jpg'
};